package com.add.smarthome.api;

public class Connection {
}
