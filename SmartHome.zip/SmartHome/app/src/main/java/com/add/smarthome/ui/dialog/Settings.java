package com.add.smarthome.ui.dialog;

public class Settings {
}
