package com.add.smarthome.utils;

public class Utils {
}
